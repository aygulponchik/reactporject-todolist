import React from 'react'

export default function TodoCard(props) {
    const { children, handleDeleteTodo, index, handleEditTodo } = props
    return (
        <div>
            <li className='todoItem'>
                {children}
                <div className="actionsContainer">
                    <button onClick={() => {
                        handleEditTodo(index)
                    }}>
                        {/* <i class="fa-solid fa-pen-to-square"></i> */}
                        r
                    </button>
                    <button onClick={() => {
                        handleDeleteTodo(index)
                    }}>
                        {/* <i class="fa-regular fa-trash-can"></i> */}
                        y
                    </button>

                </div>

            </li>
        </div>
    )
}
